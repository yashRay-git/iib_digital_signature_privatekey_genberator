package digitalSignature;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
public class JSONSignature {
	//String ReqLocation = "C:\\Users\\Sreenivas Bandaru\\Documents\\FidelityBank\\Request\\Enrollment.json";
	//String ReqLocation = "C:\\Users\\Sreenivas Bandaru\\Documents\\FidelityBank\\Request\\Delete.json";
	/*public String loadJSONFromFile(String ReqLocation) throws Exception {
        return new String(Files.readAllBytes(Paths.get(ReqLocation)), StandardCharsets.UTF_8);
    }*/
	public static String digitalSign (String reqData) {
		//JSONSignature reader = new JSONSignature();
		String signature = " ";
        try {
            // Specify the path to your JSON file
            //String jsonContent = reader.loadJSONFromFile("C:\\Users\\Sreenivas Bandaru\\Documents\\FidelityBank\\Request\\Enrollment.json");
        // Load private and public keys
        PrivateKey privateKey = loadPrivateKey("C:\\Office_WorkSpace\\FidelityBank\\Certificates\\privateKey.pem");
        //PublicKey publicKey = loadPublicKey("C:\\Users\\Sreenivas Bandaru\\Documents\\FidelityBank\\Keys\\publicKey.pem");
        //String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2/vWgJw+CuL7leYGcaZWNEgFNMwbEikfPBGh8QFdnTy6GLs1z6zpPBxk71GTR69wVoO86aBVx3EEQYfgYr7o9O/Wi6GdoPPc7i4Vnb8z7SbDyEGlDdBwZEy5e1fnr2utotQQH/GoR5pmdG3kHc4gTXBmWQfHa1hMFVoW7dJa8gjtPqCwYmiOsnTAb5jqMCTTa+5CcT+zKW65UiFGfzljwOwUf5CGZnWhxrUPoQl7IuvnTKk+lA98fa2S/GwoP3ci8ebqtP2meL68t35vtvHxz6cVHRL57L6bloI/sZdqinvy0HT3/iyldwkqsGBoMJiRhHI2hFBpRkQ0qwav5uD71QIDAQAB";
        // Sign the JSON
        signature = signJSON(reqData, privateKey);
        //System.out.println("Generated Signature: " + signature);
        
        // Verify the signature
        //boolean isVerified = verifyJSON(reqData, signature, publicKey);
        //System.out.println("Signature Verified: " + isVerified);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return signature;
    }

    // Method to sign JSON using a private key
    public static String signJSON(String json, PrivateKey privateKey) {
        Signature signature;
		try {
			signature = Signature.getInstance("SHA256withRSA");
			signature.initSign(privateKey);
	        signature.update(json.getBytes(StandardCharsets.UTF_8));
	        byte[] signedBytes = signature.sign();
	        return Base64.getEncoder().encodeToString(signedBytes);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		} catch (InvalidKeyException e) {
			e.printStackTrace();
			return null;
		} catch (SignatureException e) {
			e.printStackTrace();
			return null;
		}
        
    }

    // Method to verify JSON using a public key
    public static Boolean verifyJSON(String json, String signature) {
    	PublicKey publicKey = loadPublicKey("C:\\Office_WorkSpace\\FidelityBank\\Certificates\\publicKey.pem");
        Signature sig;
		try {
			sig = Signature.getInstance("SHA256withRSA");
			sig.initVerify(publicKey);
	        sig.update(json.getBytes(StandardCharsets.UTF_8));
	        byte[] signedBytes = Base64.getDecoder().decode(signature);
	        return sig.verify(signedBytes);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return false;
		} catch (InvalidKeyException e) {
			e.printStackTrace();
			return false;
		} catch (SignatureException e) {
			e.printStackTrace();
			return false;
		}
        
    }

    // Method to load a private key from a PEM file
    public static PrivateKey loadPrivateKey(String privateKey) {
        String key;
		try {
			key = new String(Files.readAllBytes(Paths.get(privateKey)), StandardCharsets.UTF_8);
			key = key.replace("-----BEGIN PRIVATE KEY-----", "")
	                 .replace("-----END PRIVATE KEY-----", "")
	                 .replaceAll("\\s", "");
	        byte[] keyBytes = Base64.getDecoder().decode(key);
	        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
	        KeyFactory kf = KeyFactory.getInstance("RSA");
	        return kf.generatePrivate(spec);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (InvalidKeySpecException e) {
			e.printStackTrace();
			return null;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		}
        
    }

    // Method to load a public key from a PEM file
    public static PublicKey loadPublicKey(String publicKey) {
        String key;
		try {
			key = new String(Files.readAllBytes(Paths.get(publicKey)), StandardCharsets.UTF_8);
			key = key.replace("-----BEGIN PUBLIC KEY-----", "")
	                 .replace("-----END PUBLIC KEY-----", "")
	                 .replaceAll("[\\r\\n]+", "") // Removes all newlines and carriage returns
	                 .trim(); // Remove leading/trailing spaces
	        byte[] keyBytes = Base64.getDecoder().decode(key);
	        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
	        KeyFactory kf = KeyFactory.getInstance("RSA");
	        return kf.generatePublic(spec);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		} catch (InvalidKeySpecException e) {
			e.printStackTrace();
			return null;
		}
        
    }
}
